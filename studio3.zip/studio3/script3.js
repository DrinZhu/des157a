(function(){
    'use strict';
    console.log('reading JS');

    const startGame = document.querySelector('#startgame');
    const dicescore1 = document.querySelector('#DiceScore1');
    const dicescore2 = document.querySelector('#DiceScore2');
    const currentScore1 = document.querySelector('#currentScore1');
    const currentScore2 = document.querySelector('#currentScore2');
    const diceImages = document.querySelectorAll('.dice-placeholder img');

    const gameData = {
        dice: ['images/dice1.png', 'images/dice2.png', 'images/dice3.png', 'images/dice4.png', 'images/dice5.png', 'images/dice6.png'],
        players: ['PLAYER 1', 'PLAYER 2'], 
        score: [0, 0],
        roll1: 0,
        roll2: 0,
        rollSum: 0,
        index: 0,
        gameEnd: 29
    };

    startGame.addEventListener('click', function(){
        gameData.index = Math.round(Math.random());
        setUpTurn();
    });

    function setUpTurn(){
        document.querySelector('#roll').addEventListener('click', function(){
            throwDice();
        });
    }

    function throwDice(){
        gameData.roll1 = Math.floor(Math.random() * 6) + 1;
        gameData.roll2 = Math.floor(Math.random() * 6) + 1;

        // Update dice images
        diceImages[0].src = gameData.dice[gameData.roll1-1];
        diceImages[1].src = gameData.dice[gameData.roll2-1];

        gameData.rollSum = gameData.roll1 + gameData.roll2;

        if(gameData.rollSum === 2){
            alert('Oh snap! Snake eyes!');
            gameData.score[gameData.index] = 0;
            updateScores();
            gameData.index ? (gameData.index = 0) : (gameData.index = 1);
            setUpTurn();
        } else if (gameData.roll1 === 1 || gameData.roll2 === 1) {
            alert(`One of your rolls was a one, switching to ${gameData.players[gameData.index]}`);
            gameData.index ? (gameData.index = 0) : (gameData.index = 1);
            setUpTurn();
        } else {
            gameData.score[gameData.index] += gameData.rollSum;
            checkWinningCondition();
        }
    }

    function updateScores() {
        dicescore1.textContent = gameData.score[0];
        dicescore2.textContent = gameData.score[1];
        currentScore1.textContent = gameData.score[0]; 
        currentScore2.textContent = gameData.score[1]; 
    }

    function checkWinningCondition(){
        if(gameData.score[gameData.index] > gameData.gameEnd){
            alert(`${gameData.players[gameData.index]} wins with ${gameData.score[gameData.index]} points!`);
            startGame.textContent = 'Start a new game?'; // Reset or offer a new game option
        } else {
            updateScores();
        }
    }
})();
