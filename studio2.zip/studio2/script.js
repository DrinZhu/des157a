(function(){
    'use strict';
    console.log('reading js');

    const meme = document.querySelector('#wait')

    const images= ['image1.png', 'image2.png']
    let currentImage = 0;

    document.querySelector('#send').addEventListener('click', nextPhoto);

    function nextPhoto(){
        currentImage = (currentImage + 1) % images.length;
        meme.src=`images/${images[currentImage]}`;
    }
})